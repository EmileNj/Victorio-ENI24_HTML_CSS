# Snipper-Landing-Page

Created for [codewell.cc](https://codewell.cc)

Created with **HTML** and **SCSS**

## Desktop View
![Desktop View](https://user-images.githubusercontent.com/87293899/129499161-cb7886f7-de39-484e-9b6b-c90da40708ab.png)

## Tablet View 
![Tablet View](https://user-images.githubusercontent.com/87293899/129499163-3b4f1613-7fd6-459e-9e4e-517c1dbdafb2.png)

## Mobile View
![Mobile View](https://user-images.githubusercontent.com/87293899/129499159-2fd2217c-e3df-4077-b037-a73b484e9c26.png)



